# 图标文件说明

本项目包含以下 SVG 图标文件：
- icon16.svg (16x16)
- icon32.svg (32x32) 
- icon48.svg (48x48)
- icon128.svg (128x128)

如需 PNG 格式，请使用以下方法转换：
1. 在线转换工具（如 convertio.co）
2. 使用 Inkscape: inkscape icon.svg -o icon.png
3. 使用 ImageMagick: convert icon.svg icon.png

或者直接重命名 .svg 为 .png，大多数现代浏览器都支持在 manifest.json 中使用 SVG 图标。
